/* Mills IP — Main JavaScript */

// Sticky header shadow on scroll
window.addEventListener('scroll', function() {
  var header = document.querySelector('.site-header');
  if (header) header.classList.toggle('scrolled', window.scrollY > 10);
});

// Mobile navigation toggle
document.addEventListener('DOMContentLoaded', function() {
  var toggle = document.querySelector('.mobile-toggle');
  var mobileNav = document.querySelector('.mobile-nav');
  if (toggle && mobileNav) {
    toggle.addEventListener('click', function() {
      mobileNav.classList.toggle('open');
    });
  }

  // Fade-in on scroll
  var fadeEls = document.querySelectorAll('.fade-in');
  if (fadeEls.length) {
    var observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '-40px' });
    fadeEls.forEach(function(el) { observer.observe(el); });
  }

  // FAQ Accordion
  var faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(function(item) {
    var btn = item.querySelector('.faq-question');
    if (btn) {
      btn.addEventListener('click', function() {
        var isOpen = item.classList.contains('open');
        // Close all
        faqItems.forEach(function(i) { i.classList.remove('open'); });
        // Toggle current
        if (!isOpen) item.classList.add('open');
      });
    }
  });
});

// Toast notification
function showToast(message, type) {
  var existing = document.querySelector('.toast');
  if (existing) existing.remove();
  var toast = document.createElement('div');
  toast.className = 'toast ' + (type || 'success');
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(function() { toast.remove(); }, 5000);
}

// Contact form handler
document.addEventListener('DOMContentLoaded', function() {
  var form = document.getElementById('contact-form');
  if (!form) return;

  form.addEventListener('submit', function(e) {
    e.preventDefault();
    var btn = form.querySelector('button[type="submit"]');
    var originalText = btn.innerHTML;
    btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" style="animation:spin 1s linear infinite"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" opacity="0.25"/><path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" opacity="0.75"/></svg> Sending...';
    btn.disabled = true;

    var data = {
      name: form.querySelector('[name="name"]').value,
      company: form.querySelector('[name="company"]').value,
      email: form.querySelector('[name="email"]').value,
      phone: form.querySelector('[name="phone"]').value,
      message: form.querySelector('[name="message"]').value
    };

    // Try PHP handler first, fall back to mailto
    fetch('contact-handler.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
    .then(function(res) { return res.json(); })
    .then(function(result) {
      if (result.success) {
        showToast('Thank you for your message. One of our lawyers will be in touch shortly.', 'success');
        form.reset();
      } else {
        showToast(result.error || 'Something went wrong. Please try again.', 'error');
      }
    })
    .catch(function() {
      // Fallback: open mailto link
      var subject = encodeURIComponent('Website Enquiry from ' + data.name);
      var body = encodeURIComponent('Name: ' + data.name + '\nCompany: ' + data.company + '\nEmail: ' + data.email + '\nPhone: ' + data.phone + '\n\nMessage:\n' + data.message);
      window.location.href = 'mailto:ek@millsip.com.au?subject=' + subject + '&body=' + body;
      showToast('Opening your email client...', 'success');
    })
    .finally(function() {
      btn.innerHTML = originalText;
      btn.disabled = false;
    });
  });
});

// CSS animation for spinner
var style = document.createElement('style');
style.textContent = '@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }';
document.head.appendChild(style);
