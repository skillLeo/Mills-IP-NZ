# Mills IP — Static Website

A plain HTML/CSS/JS website for Mills IP, a specialist trade mark and intellectual property law firm. No frameworks, no build tools, no Node.js required.

## File Structure

```
mills-ip-static/
├── index.html              ← Home / About page
├── services.html           ← Services page
├── integrated-tm.html      ← Integrated TM Management page
├── meet-the-team.html      ← Our Team page
├── insights.html           ← Insights listing page
├── contact.html            ← Contact page with form
├── 404.html                ← Custom 404 error page
├── contact-handler.php     ← PHP contact form handler
├── .htaccess               ← Apache config (caching, security, errors)
├── robots.txt              ← Search engine crawl instructions
├── sitemap.xml             ← XML sitemap for SEO
├── css/
│   └── style.css           ← All styles in one file
├── js/
│   └── main.js             ← Navigation, animations, form handler
└── insights/
    ├── madrid-trade-mark-system.html
    ├── business-names-vs-trade-marks.html
    └── r-symbol-when-you-can-use-it.html
```

## Deployment on cPanel

1. **Upload all files** to your `public_html` directory (or a subdirectory if using an addon domain)
2. **That's it.** The site works immediately — no build step, no npm install, no server configuration

### Contact Form

The contact form submits to `contact-handler.php` which uses PHP's `mail()` function to send enquiries to `ek@millsip.com.au`. If PHP is not available or the request fails, the form falls back to opening the visitor's email client with a pre-filled mailto link.

**To change the recipient email:** Edit line 53 in `contact-handler.php`:
```php
$to = 'ek@millsip.com.au';
```

**To use Mailgun SMTP instead of PHP mail():** Install PHPMailer via Composer and update `contact-handler.php` to use SMTP transport. See the commented section in the file for guidance.

### Custom Domain / SSL

- Point your domain's DNS A record to your hosting server's IP address
- In cPanel, go to **Domains** and add your domain
- Enable SSL via **SSL/TLS Status** → **AutoSSL** (free Let's Encrypt certificate)

### Editing the Site

Every page is a standalone HTML file. To edit content:

1. Open the relevant `.html` file in any text editor
2. Find the text you want to change
3. Save and upload the modified file

Styles are in `css/style.css`. Colours are defined as CSS variables at the top of the file — change them there to update the entire site's colour scheme.

## Key Details

- **Font:** Source Sans 3 (loaded from Google Fonts CDN)
- **Colours:** Navy (#1a2634), Brand Green (#2a7d4f), Warm Grey (#f7f5f2)
- **Images:** Hosted on CloudFront CDN — no local image files needed
- **Google Tag Manager:** GTM-59KS8DXP (already embedded in all pages)
- **Contact email:** ek@millsip.com.au
- **Phone:** 1300 568 889

## Browser Support

Works in all modern browsers (Chrome, Firefox, Safari, Edge). No polyfills needed.
