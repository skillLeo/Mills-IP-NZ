<?php
/**
 * Mills IP — Contact Form Handler (PHP)
 * 
 * This file handles contact form submissions via PHP mail().
 * Place it at the root of your hosting alongside the HTML files.
 * 
 * For Mailgun SMTP, install PHPMailer via Composer and uncomment
 * the SMTP section below.
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid request body']);
    exit;
}

$name = trim($input['name'] ?? '');
$company = trim($input['company'] ?? '');
$email = trim($input['email'] ?? '');
$phone = trim($input['phone'] ?? '');
$message = trim($input['message'] ?? '');

// Validation
if (empty($name) || empty($email) || empty($message)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Name, email, and message are required.']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Please provide a valid email address.']);
    exit;
}

// Build email
$to = 'ek@millsip.com.au';
$subject = "Website Enquiry from $name";
$headers = "From: ek@elk.com.au\r\n";
$headers .= "Reply-To: $email\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";

$htmlBody = "
<html>
<body style='font-family: Arial, sans-serif; line-height: 1.6;'>
<h2 style='color: #1a2634;'>New Website Enquiry</h2>
<table style='border-collapse: collapse; width: 100%; max-width: 600px;'>
<tr><td style='padding: 8px; border-bottom: 1px solid #eee; font-weight: bold; width: 120px;'>Name</td><td style='padding: 8px; border-bottom: 1px solid #eee;'>" . htmlspecialchars($name) . "</td></tr>
<tr><td style='padding: 8px; border-bottom: 1px solid #eee; font-weight: bold;'>Company</td><td style='padding: 8px; border-bottom: 1px solid #eee;'>" . htmlspecialchars($company ?: 'Not provided') . "</td></tr>
<tr><td style='padding: 8px; border-bottom: 1px solid #eee; font-weight: bold;'>Email</td><td style='padding: 8px; border-bottom: 1px solid #eee;'><a href='mailto:" . htmlspecialchars($email) . "'>" . htmlspecialchars($email) . "</a></td></tr>
<tr><td style='padding: 8px; border-bottom: 1px solid #eee; font-weight: bold;'>Phone</td><td style='padding: 8px; border-bottom: 1px solid #eee;'>" . htmlspecialchars($phone ?: 'Not provided') . "</td></tr>
</table>
<h3 style='color: #1a2634; margin-top: 20px;'>Message</h3>
<p style='background: #f7f5f2; padding: 16px; border-radius: 8px;'>" . nl2br(htmlspecialchars($message)) . "</p>
<hr style='border: none; border-top: 1px solid #eee; margin: 20px 0;'>
<p style='font-size: 12px; color: #999;'>Sent from millsip.com.au contact form</p>
</body>
</html>";

$sent = mail($to, $subject, $htmlBody, $headers);

if ($sent) {
    echo json_encode(['success' => true, 'emailSent' => true, 'message' => 'Your message has been received. We will be in touch shortly.']);
} else {
    // Still return success to user but flag email issue
    echo json_encode(['success' => true, 'emailSent' => false, 'message' => 'Your message has been received. We will be in touch shortly.']);
}
?>
